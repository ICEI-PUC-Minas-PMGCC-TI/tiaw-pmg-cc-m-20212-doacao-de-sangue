# Avaliação da Aplicação

## Plano de Testes

> Fizemos testes com colegas de classe e comparações com sites que tem ideias semelhantes a nossa de acordo com suas funcionalidades.

## Avaliação

> Creio que tivems bastante acertos em como pensamos na ideias e de como implementar, uma fraqueza que tivemos e que pode perpetuar é a divulgação pois mesmo com campanhas ainda é muito fraco para que as pessoas procurarem acessar sites deste tipo, talvez á melhor solução seja de centros apoiarem cadastros como um "perfil hospitalar" e talvez devemos ter refinado mais os wireframes deixando um pouco mais específico cada função.